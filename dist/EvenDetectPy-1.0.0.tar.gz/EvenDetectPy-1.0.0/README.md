# EvenDetectPy

## Python Package which will confrim if int is even.